package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Tính trajectory tên từ bow ngay lúc thả cung.
 * Học từ BOOST-FPS calcBowTrajectory pattern.
 *
 * Minecraft bow velocity formula (BowItem.onStoppedUsing):
 *   power = getPullProgress(useTimeLeft) * 3.0
 *   direction = player look vector (yaw, pitch)
 *   initialVelocity = normalize(direction) * power
 */
public final class BowTrajectoryUtil {
    private BowTrajectoryUtil() {}

    /**
     * Tính điểm rơi của tên ngay khi thả cung.
     * Gọi tại thời điểm stopUsingItem() — trước khi tên được tạo.
     *
     * @param player player đang thả cung
     * @param useTimeLeft thời gian sử dụng còn lại (tick)
     * @return BlockPos rail nên đặt, hoặc null nếu không tìm được
     */
    public static BlockPos predictLanding(ClientPlayerEntity player, int useTimeLeft) {
        World world = player.getWorld();

        // Tính power (0.0 - 1.0) rồi nhân 3.0 = tốc độ tên
        float pullProgress = BowItem.getPullProgress(useTimeLeft);
        if (pullProgress < 0.1f) return null; // cung kéo quá ít

        float speed = pullProgress * 3.0f;

        // Hướng nhìn của player (yaw, pitch) → vector velocity
        float yawRad   = (float) Math.toRadians(player.getYaw());
        float pitchRad = (float) Math.toRadians(player.getPitch());

        double vx = -Math.sin(yawRad) * Math.cos(pitchRad);
        double vy = -Math.sin(pitchRad);
        double vz =  Math.cos(yawRad) * Math.cos(pitchRad);

        // Normalize rồi nhân speed
        double len = Math.sqrt(vx*vx + vy*vy + vz*vz);
        if (len == 0) return null;
        vx = vx / len * speed;
        vy = vy / len * speed;
        vz = vz / len * speed;

        // Điểm xuất phát = eye position (tên spawn tại mắt player)
        Vec3d eye = player.getEyePos();
        double x = eye.x, y = eye.y, z = eye.z;

        // Simulate trajectory — đúng vật lý Minecraft
        for (int i = 0; i < 120; i++) {
            // Gravity và drag (giống PersistentProjectileEntity.tick)
            vy -= 0.05;
            vx *= 0.99; vy *= 0.99; vz *= 0.99;
            x += vx; y += vy; z += vz;

            BlockPos check = new BlockPos((int) Math.floor(x),
                                          (int) Math.floor(y),
                                          (int) Math.floor(z));

            // Tìm block có thể đặt rail
            if (!world.getBlockState(check).isAir() &&
                !world.getBlockState(check).isAir()) {
                // Block phía trên check phải trống để đặt rail
                BlockPos above = check.up();
                if (world.getBlockState(above).isAir()) {
                    return above;
                }
                return null;
            }

            // Check block phía dưới vị trí tên
            BlockPos floor = new BlockPos((int) Math.floor(x),
                                          (int) Math.floor(y) - 1,
                                          (int) Math.floor(z));
            if (!world.getBlockState(floor).isAir()) {
                BlockPos rail = floor.up();
                if (world.getBlockState(rail).isAir()) {
                    return rail;
                }
            }
        }
        return null;
    }

    /** Player có đang cầm bow không. */
    public static boolean isHoldingBow(ClientPlayerEntity player) {
        return player.getMainHandStack().getItem() instanceof BowItem ||
               player.getOffHandStack().getItem() instanceof BowItem;
    }
}
