package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.target.PlacementTarget;
import com.firebow.util.BowTrajectoryUtil;
import com.firebow.util.InteractionUtil;
import io.netty.channel.ChannelFutureListener;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.network.ClientConnection;

/**
 * Hook vào ClientConnection.send() AFTER packet gửi — đúng như BOOST-FPS.
 *
 * Lý do quan trọng:
 * - Trigger AFTER RELEASE_USE_ITEM packet → arrow đã được tạo rồi
 * - Không bao giờ cart trước tên vì arrow đã spawn trước khi mình làm gì
 * - Đây là cách BOOST-FPS tránh "chưa bắn tên đã đặt cart"
 */
@Environment(EnvType.CLIENT)
@Mixin(ClientConnection.class)
public class ClientConnectionMixin {

    @Inject(
        method = "send(Lnet/minecraft/network/packet/Packet;Lio/netty/channel/ChannelFutureListener;Z)V",
        at = @At("TAIL")
    )
    private void firebow$onPacketSendPost(Packet<?> packet,
                                          ChannelFutureListener listener,
                                          boolean flush,
                                          CallbackInfo ci) {
        // Chỉ quan tâm PlayerActionC2SPacket RELEASE_USE_ITEM
        if (!(packet instanceof PlayerActionC2SPacket actionPacket)) return;
        if (actionPacket.getAction() != PlayerActionC2SPacket.Action.RELEASE_USE_ITEM) return;

        FireBowRuntime rt = FireBowRuntime.get();
        if (!rt.isEnabled()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.interactionManager == null) return;
        if (!BowTrajectoryUtil.isHoldingBow(mc.player)) return;

        // Suppress FireArrowMixin — arrow vừa được tạo, bow release xử lý rồi
        rt.suppressArrowMixin();

        int useTimeLeft = mc.player.getItemUseTimeLeft();
        BlockPos railPos = BowTrajectoryUtil.predictLanding(mc.player, useTimeLeft);
        if (railPos == null) return;
        if (!InteractionUtil.inReach(mc.player, railPos)) return;

        // Khoảng cách tối thiểu 1 block
        if (mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(railPos)) < 1.0) return;

        PlacementTarget target = PlacementTarget.tryCreate(railPos);
        if (target == null) return;

        long ping = 50L;
        try {
            if (mc.getNetworkHandler() != null) {
                var e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) ping = e.getLatency();
            }
        } catch (Exception ignored) {}

        int cartDelay = ping > 200 ? 3 : ping > 100 ? 2 : 1;
        rt.scheduleBowRelease(railPos, cartDelay);
    }
}
